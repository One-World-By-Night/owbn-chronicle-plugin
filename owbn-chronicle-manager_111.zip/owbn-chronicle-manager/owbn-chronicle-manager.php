<?php
/**
 * Plugin Name: OWBN Chronicle Manager
 * Description: Manage OWBN Chronicle information using structured custom post types, shortcodes, and approval workflows.
 * Version: 1.1.1
 * Author: greghacke
 * Author URI: https://www.owbn.net
 * Text Domain: owbn-chronicle-manager
 * Domain Path: /languages
 * License: GPL-2.0-or-later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * GitHub Plugin URI: https://github.com/One-World-By-Night/owbn-chronicle-plugin
 * GitHub Branch: main
 */

// ─── Core Includes ───────────────────────────────────────────────────────────
require_once plugin_dir_path(__FILE__) . 'includes/hooks/admin-init.php';
require_once plugin_dir_path(__FILE__) . 'includes/fields.php';
require_once plugin_dir_path(__FILE__) . 'includes/hooks/save-and-validate.php';
require_once plugin_dir_path(__FILE__) . 'includes/helpers/countries.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin/enqueue-scripts.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin/options-page.php';
require_once plugin_dir_path(__FILE__) . 'includes/editor/editor-init.php';
require_once plugin_dir_path(__FILE__) . 'includes/render/render-metabox-fields.php';
require_once plugin_dir_path(__FILE__) . 'includes/render/render-location-fields.php';
require_once plugin_dir_path(__FILE__) . 'includes/render/render-session-fields.php';
require_once plugin_dir_path(__FILE__) . 'includes/render/render-user-fields.php';
require_once plugin_dir_path(__FILE__) . 'includes/render/render-links-uploads-fields.php';
require_once plugin_dir_path(__FILE__) . 'includes/shortcodes/chronicle-shortcode.php';
// require_once plugin_dir_path(__FILE__) . 'includes/hooks/i18n.php';

// ─── Activation + Deactivation ───────────────────────────────────────────────
register_activation_hook(__FILE__, 'owbn_network_or_single_activate');
register_deactivation_hook(__FILE__, 'owbn_deactivate_plugin');

/**
 * Handles plugin activation across network or individual site
 */
function owbn_network_or_single_activate($network_wide) {
    if (is_multisite() && $network_wide) {
        $sites = get_sites();
        foreach ($sites as $site) {
            switch_to_blog($site->blog_id);
            owbn_activate_plugin();
            restore_current_blog();
        }
    } else {
        owbn_activate_plugin();
    }
}

/**
 * Performs per-site activation logic
 */
function owbn_activate_plugin() {
    file_put_contents(
        WP_CONTENT_DIR . '/owbn-activation.log',
        date('c') . " - Activation running on blog ID: " . get_current_blog_id() . "\n",
        FILE_APPEND
    );

    update_option('owbn_flush_rewrite_rules', true);
    owbn_create_custom_roles();
    owbn_grant_admin_chronicle_caps();
}

// ─── Ensure Roles Are Present On Init (Subsite Safe) ─────────────────────────
add_action('init', function () {
    // Ensure all custom roles exist
    $missing_roles = array_filter([
        'chron_staff',
        'web_team',
        'exec_team',
    ], function ($role) {
        return !get_role($role);
    });

    if (!empty($missing_roles)) {
        owbn_create_custom_roles();
    }

    // Grant capabilities to administrator if not already granted
    if (current_user_can('administrator')) {
        owbn_grant_admin_chronicle_caps();
    }

    // Auto-flush rewrite rules once if needed
    if (get_option('owbn_flush_rewrite_rules')) {
        flush_rewrite_rules();
        delete_option('owbn_flush_rewrite_rules');
    }
}, 5);