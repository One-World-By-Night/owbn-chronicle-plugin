<?php

/** File: includes/templates/init.php
 * Text Domain: accessschema-client
 * version 1.2.0
 *
 * @author greghacke
 * Function: Init teamplates functionality for the plugin
 */

defined( 'ABSPATH' ) || exit;

/** --- Require each render file once --- */
