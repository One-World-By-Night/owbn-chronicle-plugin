<?php
if (!defined('ABSPATH')) exit;

if (!function_exists('owbn_safe_post_value')) {
    function owbn_safe_post_value($key, $source = null)
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $source = $source ?? $_POST;
        if (!isset($source[$key])) return '';
        return is_array($source[$key]) ? $source[$key] : stripslashes($source[$key]);
    }
}

if (!function_exists('owbn_users_changed')) {
    function owbn_users_changed($old, $new)
    {
        $old_users = array_filter(array_map(fn($u) => trim(strtolower((string)$u)), is_array($old) ? $old : []));
        $new_users = array_filter(array_map(fn($u) => trim(strtolower((string)$u)), is_array($new) ? $new : []));
        sort($old_users);
        sort($new_users);
        return $old_users !== $new_users;
    }
}

if (!function_exists('owbn_is_admin_user')) {
    function owbn_is_admin_user($user = null)
    {
        if ($user === null) {
            $user = wp_get_current_user();
        } elseif (is_int($user)) {
            $user = get_userdata($user);
        }

        if (!$user instanceof WP_User) return false;

        return !empty(array_intersect($user->roles, ['administrator', 'exec_team', 'web_team']));
    }
}

if (!function_exists('owbn_sanitize_user_info')) {
    function owbn_sanitize_user_info($info)
    {
        if (!is_array($info)) return [];

        return [
            'user'          => sanitize_text_field($info['user'] ?? ''),
            'display_name'  => sanitize_text_field($info['display_name'] ?? ''),
            'email'         => sanitize_email($info['email'] ?? ''),
            'actual_email'  => sanitize_email($info['actual_email'] ?? ''),
            'display_email' => sanitize_email($info['display_email'] ?? ''),
        ];
    }
}

if (!function_exists('owbn_sanitize_ast_group')) {
    function owbn_sanitize_ast_group($group_data, $meta_fields)
    {
        $cleaned = [];

        if (!is_array($group_data)) return $cleaned;

        foreach ($group_data as $index => $row) {
            if ($index === '__INDEX__') continue;
            if (empty($row['user']) && empty($row['display_name']) && empty($row['email']) && empty($row['role'])) {
                continue;
            }

            $row_cleaned = [];
            foreach ($meta_fields as $sub_key => $sub_meta) {
                if (!isset($row[$sub_key])) continue;
                $raw = $row[$sub_key];

                if (in_array($sub_key, ['email', 'actual_email', 'display_email'], true)) {
                    $row_cleaned[$sub_key] = sanitize_email($raw);
                } else {
                    $row_cleaned[$sub_key] = is_array($raw)
                        ? array_map('sanitize_text_field', $raw)
                        : sanitize_text_field($raw);
                }
            }

            $cleaned[] = $row_cleaned;
        }

        return $cleaned;
    }
}

if (!function_exists('owbn_sanitize_document_links')) {
    function owbn_sanitize_document_links($group_data, $post_id, $field_key, $existing_meta = null)
    {
        $cleaned = [];

        if (!is_array($group_data)) return $cleaned;

        foreach ($group_data as $index => $row) {
            if ($index === '__INDEX__') continue;

            $row_cleaned = [
                'title'        => isset($row['title']) ? sanitize_text_field($row['title']) : '',
                'link'         => isset($row['link']) ? esc_url_raw($row['link']) : '',
                'last_updated' => isset($row['last_updated']) ? sanitize_text_field($row['last_updated']) : '',
            ];

            // Handle uploaded file
            $file_field = "{$field_key}_{$index}_upload";
            if (!empty($_FILES[$file_field]) && !empty($_FILES[$file_field]['tmp_name'])) {
                require_once ABSPATH . 'wp-admin/includes/file.php';
                require_once ABSPATH . 'wp-admin/includes/media.php';
                require_once ABSPATH . 'wp-admin/includes/image.php';

                $attachment_id = media_handle_upload($file_field, $post_id);
                if (!is_wp_error($attachment_id)) {
                    $row_cleaned['file_id'] = $attachment_id;
                    if (empty($row_cleaned['last_updated'])) {
                        $row_cleaned['last_updated'] = current_time('Y-m-d');
                    }
                }
            } elseif (is_array($existing_meta) && isset($existing_meta[$index]['file_id'])) {
                $row_cleaned['file_id'] = $existing_meta[$index]['file_id'];
            }

            $cleaned[] = $row_cleaned;
        }

        return $cleaned;
    }
}

if (!function_exists('owbn_sanitize_email_lists')) {
    function owbn_sanitize_email_lists($group_data)
    {
        $cleaned = [];

        if (!is_array($group_data)) return $cleaned;

        foreach ($group_data as $index => $row) {
            if ($index === '__INDEX__') continue;

            $row_cleaned = [
                'list_name'     => isset($row['list_name']) ? sanitize_text_field($row['list_name']) : '',
                'email_address' => isset($row['email_address']) ? sanitize_email($row['email_address']) : '',
                'description'   => isset($row['description']) ? wp_kses_post($row['description']) : '',
            ];

            if ($row_cleaned['list_name'] || $row_cleaned['email_address'] || $row_cleaned['description']) {
                $cleaned[] = $row_cleaned;
            }
        }

        return $cleaned;
    }
}

if (!function_exists('owbn_sanitize_player_lists')) {
    function owbn_sanitize_player_lists($group_data)
    {
        $cleaned = [];

        if (!is_array($group_data)) return $cleaned;

        foreach ($group_data as $index => $row) {
            if ($index === '__INDEX__') continue;
            if (empty($row['list_name'])) continue;

            $cleaned[] = [
                'list_name'        => sanitize_text_field($row['list_name'] ?? ''),
                'access'           => sanitize_text_field($row['access'] ?? 'Public'),
                'address'          => sanitize_email($row['address'] ?? ''),
                'ic_ooc'           => sanitize_text_field($row['ic_ooc'] ?? 'OOC'),
                'moderate_address' => sanitize_email($row['moderate_address'] ?? ''),
                'signup_url'       => esc_url_raw($row['signup_url'] ?? ''),
            ];
        }

        return $cleaned;
    }
}

if (!function_exists('owbn_sanitize_social_links')) {
    function owbn_sanitize_social_links($group_data)
    {
        $cleaned = [];

        if (!is_array($group_data)) return $cleaned;

        foreach ($group_data as $index => $row) {
            if ($index === '__INDEX__' || (empty($row['platform']) && empty($row['url']))) {
                continue;
            }

            $cleaned[] = [
                'platform' => isset($row['platform']) ? sanitize_text_field($row['platform']) : '',
                'url'      => isset($row['url']) ? esc_url_raw($row['url']) : '',
            ];
        }

        return $cleaned;
    }
}

/**
 * Filter personnel data for API responses.
 *
 * Strips internal fields (user ID, actual_email) and returns only
 * public-facing display fields.
 *
 * @param mixed $raw_value Raw personnel meta value.
 * @return array Filtered personnel data.
 */
function owbn_filter_personnel_list($raw_value)
{
    if (!is_array($raw_value)) {
        return [];
    }

    // Single user_info structure
    if (isset($raw_value['display_name'])) {
        return [
            'display_name'  => $raw_value['display_name'] ?? '',
            'display_email' => $raw_value['display_email'] ?? '',
        ];
    }

    // Array of user_info structures
    $filtered = [];
    foreach ($raw_value as $person) {
        if (!is_array($person)) continue;

        $entry = [
            'display_name'  => $person['display_name'] ?? '',
            'display_email' => $person['display_email'] ?? '',
        ];

        if (isset($person['role'])) {
            $entry['role'] = $person['role'];
        }

        $filtered[] = $entry;
    }

    return $filtered;
}

/**
 * Strip wysiwyg subfields from array data for list API responses.
 *
 * Removes large HTML content subfields that are only needed in detail view.
 *
 * @param array $value      The array field value.
 * @param array $definition The field definition (with 'fields' sub-definitions).
 * @return array Filtered array with wysiwyg subfields removed.
 */
function owbn_strip_wysiwyg_subfields($value, $definition)
{
    if (!is_array($value)) return $value;

    $subfields = $definition['fields'] ?? [];

    foreach ($value as &$item) {
        if (!is_array($item)) continue;

        foreach ($subfields as $sub_key => $sub_def) {
            if (($sub_def['type'] ?? '') === 'wysiwyg' && isset($item[$sub_key])) {
                unset($item[$sub_key]);
            }
        }
    }

    return $value;
}

function owbn_format_document_links($document_links)
{
    if (!is_array($document_links)) {
        return [];
    }

    $formatted = [];
    foreach ($document_links as $doc) {
        if (!is_array($doc)) continue;

        $url = '';
        if (!empty($doc['file_id'])) {
            $url = wp_get_attachment_url($doc['file_id']);
        } elseif (!empty($doc['link'])) {
            $url = $doc['link'];
        }

        $formatted[] = [
            'title'        => $doc['title'] ?? '',
            'url'          => $url,
            'description'  => $doc['description'] ?? '',
            'last_updated' => $doc['last_updated'] ?? '',
        ];
    }

    return $formatted;
}
