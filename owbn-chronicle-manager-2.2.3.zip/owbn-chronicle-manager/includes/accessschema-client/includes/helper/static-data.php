<?php

/** File: includes/helper/static-data.php
 * Text Domain: accessschema-client
 * version 2.0.4
 *
 * @author greghacke
 * Function: Declarative static data for the plugin
 */

defined( 'ABSPATH' ) || exit;
