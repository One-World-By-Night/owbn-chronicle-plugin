<?php
/**
 * Elementor Widgets Loader
 *
 * Registers Elementor widgets and category for OWBN Entity displays.
 *
 * @package OWBN-Chronicle-Manager
 * @version 2.2.0
 */

defined('ABSPATH') || exit;

class OWBN_Elementor_Widgets_Loader
{
	/**
	 * Initialize the loader.
	 */
	public static function init(): void
	{
		// Handle both load orders: our plugin before/after Elementor
		if (did_action('elementor/loaded')) {
			self::register_hooks();
		} else {
			add_action('elementor/loaded', [__CLASS__, 'register_hooks']);
		}
	}

	/**
	 * Register Elementor hooks.
	 */
	public static function register_hooks(): void
	{
		add_action('elementor/widgets/register', [__CLASS__, 'register_widgets']);
		add_action('elementor/elements/categories_registered', [__CLASS__, 'register_category']);
	}

	/**
	 * Register the OWBN Entities widget category.
	 *
	 * @param \Elementor\Elements_Manager $elements_manager Elementor elements manager.
	 */
	public static function register_category($elements_manager): void
	{
		$elements_manager->add_category(
			'owbn-entities',
			[
				'title' => __('OWBN Entities', 'owbn-chronicle-manager'),
				'icon'  => 'eicon-person',
			]
		);
	}

	/**
	 * Register Elementor widgets.
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
	 */
	public static function register_widgets($widgets_manager): void
	{
		// Load widget classes
		require_once __DIR__ . '/class-staff-widget.php';
		require_once __DIR__ . '/class-sessions-widget.php';
		require_once __DIR__ . '/class-links-widget.php';
		require_once __DIR__ . '/class-entity-meta-widget.php';

		// Register widgets
		$widgets_manager->register(new OWBN_Staff_Widget());
		$widgets_manager->register(new OWBN_Sessions_Widget());
		$widgets_manager->register(new OWBN_Links_Widget());
		$widgets_manager->register(new OWBN_Entity_Meta_Widget());
	}
}

// Initialize
OWBN_Elementor_Widgets_Loader::init();
