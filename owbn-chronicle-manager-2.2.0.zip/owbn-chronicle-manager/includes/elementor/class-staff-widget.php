<?php
/**
 * Staff Display Widget
 *
 * Displays staff members (HST, CM, AST, Coordinator, etc.) with styling controls.
 *
 * @package OWBN-Chronicle-Manager
 * @version 2.2.0
 */

defined('ABSPATH') || exit;

class OWBN_Staff_Widget extends \Elementor\Widget_Base
{
	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name(): string
	{
		return 'owbn_staff';
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title(): string
	{
		return __('Entity Staff', 'owbn-chronicle-manager');
	}

	/**
	 * Get widget icon.
	 *
	 * @return string
	 */
	public function get_icon(): string
	{
		return 'eicon-person';
	}

	/**
	 * Get widget categories.
	 *
	 * @return array
	 */
	public function get_categories(): array
	{
		return ['owbn-entities'];
	}

	/**
	 * Register widget controls.
	 *
	 * @return void
	 */
	protected function register_controls(): void
	{
		// Content Controls
		$this->start_controls_section(
			'content_section',
			[
				'label' => __('Content', 'owbn-chronicle-manager'),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'staff_type',
			[
				'label'       => __('Staff Type', 'owbn-chronicle-manager'),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'options'     => [
					'all'            => __('All Staff', 'owbn-chronicle-manager'),
					'hst_info'       => __('Head Storyteller', 'owbn-chronicle-manager'),
					'cm_info'        => __('Chronicle Manager', 'owbn-chronicle-manager'),
					'ast_list'       => __('Assistant Storytellers', 'owbn-chronicle-manager'),
					'coord_info'     => __('Coordinator', 'owbn-chronicle-manager'),
					'subcoord_list'  => __('Sub-Coordinators', 'owbn-chronicle-manager'),
					'admin_contact'  => __('Admin Contact', 'owbn-chronicle-manager'),
				],
				'default'     => 'all',
				'label_block' => true,
			]
		);

		$this->add_control(
			'show_section_title',
			[
				'label'   => __('Show Section Title', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_email',
			[
				'label'   => __('Show Email', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		// Style: Section Title
		$this->start_controls_section(
			'section_title_style',
			[
				'label'     => __('Section Title', 'owbn-chronicle-manager'),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_section_title' => 'yes',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'section_title_typography',
				'selector' => '{{WRAPPER}} .owbn-staff-section-title',
			]
		);

		$this->add_control(
			'section_title_color',
			[
				'label'     => __('Color', 'owbn-chronicle-manager'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owbn-staff-section-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'section_title_spacing',
			[
				'label'      => __('Spacing', 'owbn-chronicle-manager'),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', 'em'],
				'range'      => [
					'px' => ['min' => 0, 'max' => 50],
					'em' => ['min' => 0, 'max' => 5],
				],
				'selectors'  => [
					'{{WRAPPER}} .owbn-staff-section-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Style: Staff Name
		$this->start_controls_section(
			'staff_name_style',
			[
				'label' => __('Staff Name', 'owbn-chronicle-manager'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'staff_name_typography',
				'selector' => '{{WRAPPER}} .owbn-staff-name',
			]
		);

		$this->add_control(
			'staff_name_color',
			[
				'label'     => __('Color', 'owbn-chronicle-manager'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owbn-staff-name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// Style: Email Link
		$this->start_controls_section(
			'email_link_style',
			[
				'label'     => __('Email Link', 'owbn-chronicle-manager'),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_email' => 'yes',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'email_link_typography',
				'selector' => '{{WRAPPER}} .owbn-staff-email',
			]
		);

		$this->add_control(
			'email_link_color',
			[
				'label'     => __('Color', 'owbn-chronicle-manager'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owbn-staff-email' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'email_link_hover_color',
			[
				'label'     => __('Hover Color', 'owbn-chronicle-manager'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owbn-staff-email:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// Style: Container
		$this->start_controls_section(
			'container_style',
			[
				'label' => __('Container', 'owbn-chronicle-manager'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'staff_spacing',
			[
				'label'      => __('Staff Item Spacing', 'owbn-chronicle-manager'),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', 'em'],
				'range'      => [
					'px' => ['min' => 0, 'max' => 50],
					'em' => ['min' => 0, 'max' => 5],
				],
				'selectors'  => [
					'{{WRAPPER}} .owbn-staff-member' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'     => 'container_background',
				'selector' => '{{WRAPPER}} .owbn-staff-container',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'container_border',
				'selector' => '{{WRAPPER}} .owbn-staff-container',
			]
		);

		$this->add_responsive_control(
			'container_padding',
			[
				'label'      => __('Padding', 'owbn-chronicle-manager'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .owbn-staff-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output.
	 *
	 * @return void
	 */
	protected function render(): void
	{
		$settings   = $this->get_settings_for_display();
		$staff_type = $settings['staff_type'] ?? 'all';

		$post_id   = get_the_ID();
		$post_type = get_post_type($post_id);
		$config    = owbn_get_entity_config($post_type);

		if (!$config) {
			echo '<p>' . __('Not an entity post type.', 'owbn-chronicle-manager') . '</p>';
			return;
		}

		// Get staff fields from config
		$staff_fields = $config['staff_fields'] ?? [];

		// If specific type requested, filter to just that field
		if ($staff_type !== 'all') {
			$staff_fields = in_array($staff_type, $staff_fields, true) ? [$staff_type] : [];
		}

		if (empty($staff_fields)) {
			echo '<p>' . __('No staff configured for this entity type.', 'owbn-chronicle-manager') . '</p>';
			return;
		}

		echo '<div class="owbn-staff-container">';

		foreach ($staff_fields as $field_key) {
			$value = get_post_meta($post_id, $field_key, true);

			if (empty($value)) {
				continue;
			}

			// Get field definition
			$field_definitions = [];
			if (isset($config['field_definitions']) && is_callable($config['field_definitions'])) {
				$field_definitions = call_user_func($config['field_definitions']);
			}

			$field_def = null;
			foreach ($field_definitions as $group) {
				if (isset($group[$field_key])) {
					$field_def = $group[$field_key];
					break;
				}
			}

			if (!$field_def) {
				continue;
			}

			// Show section title if enabled
			if (($settings['show_section_title'] ?? 'yes') === 'yes') {
				echo '<h3 class="owbn-staff-section-title">' . esc_html($field_def['label']) . '</h3>';
			}

			// Render based on field type
			if ($field_def['type'] === 'user_info') {
				// Single staff member
				$this->render_user_info($value, $settings);
			} elseif (in_array($field_def['type'], ['ast_group', 'subcoord_group'], true)) {
				// Group of staff members
				if (is_array($value)) {
					foreach ($value as $entry) {
						$this->render_user_info($entry, $settings);
					}
				}
			}
		}

		echo '</div>';
	}

	/**
	 * Render a single user info block.
	 *
	 * @param array $user_info User info array.
	 * @param array $settings  Widget settings.
	 * @return void
	 */
	protected function render_user_info(array $user_info, array $settings): void
	{
		if (empty($user_info)) {
			return;
		}

		$display_name  = $user_info['display_name'] ?? '[Unknown]';
		$display_email = $user_info['display_email'] ?? '';
		$show_email    = ($settings['show_email'] ?? 'yes') === 'yes';

		echo '<div class="owbn-staff-member">';
		echo '<span class="owbn-staff-name">' . esc_html($display_name) . '</span>';

		if ($show_email && !empty($display_email)) {
			echo ' &mdash; <a class="owbn-staff-email" href="mailto:' . esc_attr($display_email) . '">' . esc_html($display_email) . '</a>';
		}

		echo '</div>';
	}
}
