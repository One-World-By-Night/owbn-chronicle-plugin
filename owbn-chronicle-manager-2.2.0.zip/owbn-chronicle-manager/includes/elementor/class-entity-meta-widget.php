<?php
/**
 * Entity Meta Widget
 *
 * Generic widget to display any entity field with label/value layout and styling controls.
 *
 * @package OWBN-Chronicle-Manager
 * @version 2.2.0
 */

defined('ABSPATH') || exit;

class OWBN_Entity_Meta_Widget extends \Elementor\Widget_Base
{
	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name(): string
	{
		return 'owbn_entity_meta';
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title(): string
	{
		return __('Entity Meta Field', 'owbn-chronicle-manager');
	}

	/**
	 * Get widget icon.
	 *
	 * @return string
	 */
	public function get_icon(): string
	{
		return 'eicon-info-circle';
	}

	/**
	 * Get widget categories.
	 *
	 * @return array
	 */
	public function get_categories(): array
	{
		return ['owbn-entities'];
	}

	/**
	 * Register widget controls.
	 *
	 * @return void
	 */
	protected function register_controls(): void
	{
		// Content Controls
		$this->start_controls_section(
			'content_section',
			[
				'label' => __('Content', 'owbn-chronicle-manager'),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'field_key',
			[
				'label'       => __('Field', 'owbn-chronicle-manager'),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'options'     => $this->get_field_options(),
				'default'     => '',
				'label_block' => true,
			]
		);

		$this->add_control(
			'show_label',
			[
				'label'   => __('Show Label', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'custom_label',
			[
				'label'       => __('Custom Label', 'owbn-chronicle-manager'),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
				'condition'   => [
					'show_label' => 'yes',
				],
			]
		);

		$this->add_control(
			'layout',
			[
				'label'   => __('Layout', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'inline'  => __('Inline (Label: Value)', 'owbn-chronicle-manager'),
					'stacked' => __('Stacked (Label above Value)', 'owbn-chronicle-manager'),
				],
				'default' => 'inline',
			]
		);

		$this->end_controls_section();

		// Style: Label
		$this->start_controls_section(
			'label_style',
			[
				'label'     => __('Label', 'owbn-chronicle-manager'),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_label' => 'yes',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'label_typography',
				'selector' => '{{WRAPPER}} .owbn-meta-label',
			]
		);

		$this->add_control(
			'label_color',
			[
				'label'     => __('Color', 'owbn-chronicle-manager'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owbn-meta-label' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'label_spacing',
			[
				'label'      => __('Spacing', 'owbn-chronicle-manager'),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', 'em'],
				'range'      => [
					'px' => ['min' => 0, 'max' => 50],
					'em' => ['min' => 0, 'max' => 5],
				],
				'selectors'  => [
					'{{WRAPPER}} .owbn-meta-layout-inline .owbn-meta-label'  => 'margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .owbn-meta-layout-stacked .owbn-meta-label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Style: Value
		$this->start_controls_section(
			'value_style',
			[
				'label' => __('Value', 'owbn-chronicle-manager'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'value_typography',
				'selector' => '{{WRAPPER}} .owbn-meta-value',
			]
		);

		$this->add_control(
			'value_color',
			[
				'label'     => __('Color', 'owbn-chronicle-manager'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owbn-meta-value' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// Style: Container
		$this->start_controls_section(
			'container_style',
			[
				'label' => __('Container', 'owbn-chronicle-manager'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'     => 'container_background',
				'selector' => '{{WRAPPER}} .owbn-meta-field',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'container_border',
				'selector' => '{{WRAPPER}} .owbn-meta-field',
			]
		);

		$this->add_responsive_control(
			'container_padding',
			[
				'label'      => __('Padding', 'owbn-chronicle-manager'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .owbn-meta-field' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Get available field options for the current post type.
	 *
	 * @return array
	 */
	protected function get_field_options(): array
	{
		// In editor mode, we might not have a post context
		$post_id = get_the_ID();

		if (!$post_id) {
			// Try to get post from Elementor editor
			if (isset($_GET['post'])) {
				$post_id = absint($_GET['post']);
			}
		}

		if (!$post_id) {
			return ['' => __('Select a field', 'owbn-chronicle-manager')];
		}

		$post_type = get_post_type($post_id);
		$config    = owbn_get_entity_config($post_type);

		if (!$config) {
			return ['' => __('Not an entity post type', 'owbn-chronicle-manager')];
		}

		// Get field definitions from config
		$field_definitions = [];
		if (isset($config['field_definitions']) && is_callable($config['field_definitions'])) {
			$field_definitions = call_user_func($config['field_definitions']);
		}

		$options = ['' => __('Select a field', 'owbn-chronicle-manager')];

		foreach ($field_definitions as $group_label => $fields) {
			foreach ($fields as $field_id => $field) {
				// Skip complex group types - those should use specialized widgets
				if (in_array($field['type'] ?? '', ['session_group', 'ast_group', 'document_links_group', 'social_links_group', 'email_lists_group'], true)) {
					continue;
				}

				$label = $field['label'] ?? ucfirst(str_replace('_', ' ', $field_id));
				$options[$field_id] = $label;
			}
		}

		return $options;
	}

	/**
	 * Render the widget output.
	 *
	 * @return void
	 */
	protected function render(): void
	{
		$settings  = $this->get_settings_for_display();
		$field_key = $settings['field_key'] ?? '';

		if (empty($field_key)) {
			echo '<p>' . __('Please select a field.', 'owbn-chronicle-manager') . '</p>';
			return;
		}

		$post_id   = get_the_ID();
		$post_type = get_post_type($post_id);
		$config    = owbn_get_entity_config($post_type);

		if (!$config) {
			echo '<p>' . __('Not an entity post type.', 'owbn-chronicle-manager') . '</p>';
			return;
		}

		// Get field value
		$value = get_post_meta($post_id, $field_key, true);

		if (empty($value)) {
			return;
		}

		// Get field definition for formatting
		$field_definitions = [];
		if (isset($config['field_definitions']) && is_callable($config['field_definitions'])) {
			$field_definitions = call_user_func($config['field_definitions']);
		}

		$field_def = null;
		foreach ($field_definitions as $group) {
			if (isset($group[$field_key])) {
				$field_def = $group[$field_key];
				break;
			}
		}

		if (!$field_def) {
			return;
		}

		$layout      = $settings['layout'] ?? 'inline';
		$show_label  = ($settings['show_label'] ?? 'yes') === 'yes';
		$custom_label = $settings['custom_label'] ?? '';

		// Format value based on field type
		$formatted_value = $this->format_field_value($value, $field_def);

		// Render
		echo '<div class="owbn-meta-field owbn-meta-layout-' . esc_attr($layout) . '">';

		if ($show_label) {
			$label = !empty($custom_label) ? $custom_label : ($field_def['label'] ?? ucfirst(str_replace('_', ' ', $field_key)));
			echo '<span class="owbn-meta-label">' . esc_html($label) . ':</span>';
		}

		echo '<span class="owbn-meta-value">' . wp_kses_post($formatted_value) . '</span>';

		echo '</div>';
	}

	/**
	 * Format field value based on field type.
	 *
	 * @param mixed $value     Field value.
	 * @param array $field_def Field definition.
	 * @return string Formatted value.
	 */
	protected function format_field_value($value, array $field_def): string
	{
		$type = $field_def['type'] ?? 'text';

		switch ($type) {
			case 'url':
				return sprintf('<a href="%s" target="_blank" rel="noopener">%s</a>', esc_url($value), esc_html($value));

			case 'email':
				return sprintf('<a href="mailto:%s">%s</a>', esc_attr($value), esc_html($value));

			case 'date':
				return date_i18n(get_option('date_format'), strtotime($value));

			case 'boolean':
			case 'checkbox':
				return $value ? __('Yes', 'owbn-chronicle-manager') : __('No', 'owbn-chronicle-manager');

			case 'select':
				// If field has options, look up the label
				if (isset($field_def['options']) && is_array($field_def['options'])) {
					return $field_def['options'][$value] ?? $value;
				}
				return $value;

			case 'multi_select':
				if (is_array($value)) {
					// If field has options, look up labels
					if (isset($field_def['options']) && is_array($field_def['options'])) {
						$labels = array_map(function ($val) use ($field_def) {
							return $field_def['options'][$val] ?? $val;
						}, $value);
						return implode(', ', $labels);
					}
					return implode(', ', $value);
				}
				return $value;

			case 'textarea':
				return wpautop($value);

			case 'wysiwyg':
				return wpautop($value);

			case 'user_info':
				if (is_array($value)) {
					$name  = $value['display_name'] ?? '[Unknown]';
					$email = $value['display_email'] ?? '';
					$output = esc_html($name);
					if (!empty($email)) {
						$output .= ' &mdash; <a href="mailto:' . esc_attr($email) . '">' . esc_html($email) . '</a>';
					}
					return $output;
				}
				return esc_html($value);

			default:
				return esc_html($value);
		}
	}
}
