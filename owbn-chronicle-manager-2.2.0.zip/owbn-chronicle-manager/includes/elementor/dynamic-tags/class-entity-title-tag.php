<?php
/**
 * Entity Title Dynamic Tag
 *
 * Returns the title of the current entity post.
 *
 * @package OWBN-Chronicle-Manager
 * @version 2.2.0
 */

defined('ABSPATH') || exit;

class OWBN_Entity_Title_Tag extends \Elementor\Core\DynamicTags\Tag
{
	/**
	 * Get tag name.
	 *
	 * @return string
	 */
	public function get_name(): string
	{
		return 'owbn-entity-title';
	}

	/**
	 * Get tag title.
	 *
	 * @return string
	 */
	public function get_title(): string
	{
		return __('Entity Title', 'owbn-chronicle-manager');
	}

	/**
	 * Get tag group.
	 *
	 * @return string
	 */
	public function get_group(): string
	{
		return 'owbn-entity';
	}

	/**
	 * Get tag categories.
	 *
	 * @return array
	 */
	public function get_categories(): array
	{
		return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
	}

	/**
	 * Render the tag output.
	 *
	 * @return void
	 */
	public function render(): void
	{
		$post_id = get_the_ID();

		if (!$post_id) {
			return;
		}

		// Check if this is an entity post type
		$post_type = get_post_type($post_id);
		if (!owbn_is_entity_post_type($post_type)) {
			return;
		}

		echo wp_kses_post(get_the_title($post_id));
	}
}
