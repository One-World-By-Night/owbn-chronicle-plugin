<?php
/**
 * Entity Staff Dynamic Tag
 *
 * Renders staff member blocks (HST, CM, AST, etc.) for the current entity.
 * Delegates to existing render functions for consistent output.
 *
 * @package OWBN-Chronicle-Manager
 * @version 2.2.0
 */

defined('ABSPATH') || exit;

class OWBN_Entity_Staff_Tag extends \Elementor\Core\DynamicTags\Tag
{
	/**
	 * Get tag name.
	 *
	 * @return string
	 */
	public function get_name(): string
	{
		return 'owbn-entity-staff';
	}

	/**
	 * Get tag title.
	 *
	 * @return string
	 */
	public function get_title(): string
	{
		return __('Entity Staff', 'owbn-chronicle-manager');
	}

	/**
	 * Get tag group.
	 *
	 * @return string
	 */
	public function get_group(): string
	{
		return 'owbn-entity';
	}

	/**
	 * Get tag categories.
	 *
	 * @return array
	 */
	public function get_categories(): array
	{
		return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
	}

	/**
	 * Register tag controls.
	 *
	 * @return void
	 */
	protected function register_controls(): void
	{
		$this->add_control(
			'staff_type',
			[
				'label'       => __('Staff Type', 'owbn-chronicle-manager'),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'options'     => [
					'all'      => __('All Staff', 'owbn-chronicle-manager'),
					'hst_info' => __('Head Storyteller', 'owbn-chronicle-manager'),
					'cm_info'  => __('Chronicle Manager', 'owbn-chronicle-manager'),
					'ast_list' => __('Assistant Storytellers', 'owbn-chronicle-manager'),
					'coord_info' => __('Coordinator', 'owbn-chronicle-manager'),
					'subcoord_list' => __('Sub-Coordinators', 'owbn-chronicle-manager'),
				],
				'default'     => 'all',
				'label_block' => true,
			]
		);
	}

	/**
	 * Render the tag output.
	 *
	 * @return void
	 */
	public function render(): void
	{
		$settings   = $this->get_settings();
		$staff_type = $settings['staff_type'] ?? 'all';

		$post_id   = get_the_ID();
		$post_type = get_post_type($post_id);
		$config    = owbn_get_entity_config($post_type);

		if (!$config) {
			return;
		}

		// Get staff fields from config
		$staff_fields = $config['staff_fields'] ?? [];

		// If specific type requested, filter to just that field
		if ($staff_type !== 'all') {
			$staff_fields = in_array($staff_type, $staff_fields, true) ? [$staff_type] : [];
		}

		if (empty($staff_fields)) {
			return;
		}

		echo '<div class="owbn-entity-staff">';

		foreach ($staff_fields as $field_key) {
			$value = get_post_meta($post_id, $field_key, true);

			if (empty($value)) {
				continue;
			}

			// Get field definition
			$field_definitions = [];
			if (isset($config['field_definitions']) && is_callable($config['field_definitions'])) {
				$field_definitions = call_user_func($config['field_definitions']);
			}

			$field_def = null;
			foreach ($field_definitions as $group) {
				if (isset($group[$field_key])) {
					$field_def = $group[$field_key];
					break;
				}
			}

			if (!$field_def) {
				continue;
			}

			// Render based on field type
			echo '<div class="owbn-staff-field">';
			echo '<h3>' . esc_html($field_def['label']) . '</h3>';

			if ($field_def['type'] === 'user_info') {
				// Single staff member
				$this->render_user_info($value);
			} elseif (in_array($field_def['type'], ['ast_group', 'subcoord_group'], true)) {
				// Group of staff members
				if (is_array($value)) {
					foreach ($value as $entry) {
						$this->render_user_info($entry);
					}
				}
			}

			echo '</div>';
		}

		echo '</div>';
	}

	/**
	 * Render a single user info block.
	 *
	 * @param array $user_info User info array.
	 * @return void
	 */
	protected function render_user_info(array $user_info): void
	{
		if (empty($user_info)) {
			return;
		}

		$display_name = $user_info['display_name'] ?? '[Unknown]';
		$display_email = $user_info['display_email'] ?? '';

		echo '<div class="owbn-staff-member">';
		echo '<span class="staff-name">' . esc_html($display_name) . '</span>';

		if (!empty($display_email)) {
			echo ' &mdash; <a href="mailto:' . esc_attr($display_email) . '">' . esc_html($display_email) . '</a>';
		}

		echo '</div>';
	}
}
