<?php
/**
 * Dynamic Tags Loader
 *
 * Registers all OWBN entity dynamic tags with Elementor Pro.
 * Dynamic tags allow content to be pulled from the current entity post.
 *
 * @package OWBN-Chronicle-Manager
 * @version 2.2.0
 */

defined('ABSPATH') || exit;

class OWBN_Dynamic_Tags_Loader
{
	/**
	 * Initialize the loader.
	 */
	public static function init(): void
	{
		// Check if Elementor Pro dynamic tags are available
		if (!did_action('elementor_pro/init')) {
			add_action('elementor_pro/init', [__CLASS__, 'init']);
			return;
		}

		// Register tags after Elementor's dynamic tags are registered
		add_action('elementor/dynamic_tags/register', [__CLASS__, 'register_tags']);
	}

	/**
	 * Register dynamic tags group and tags.
	 *
	 * @param \Elementor\Core\DynamicTags\Manager $dynamic_tags Elementor dynamic tags manager.
	 * @return void
	 */
	public static function register_tags($dynamic_tags): void
	{
		// Register custom tag group
		$dynamic_tags->register_group(
			'owbn-entity',
			[
				'title' => __('OWBN Entity', 'owbn-chronicle-manager'),
			]
		);

		// Load tag classes
		require_once __DIR__ . '/class-entity-title-tag.php';
		require_once __DIR__ . '/class-entity-field-tag.php';
		require_once __DIR__ . '/class-entity-staff-tag.php';
		require_once __DIR__ . '/class-entity-sessions-tag.php';
		require_once __DIR__ . '/class-entity-links-tag.php';

		// Register tags
		$dynamic_tags->register(new OWBN_Entity_Title_Tag());
		$dynamic_tags->register(new OWBN_Entity_Field_Tag());
		$dynamic_tags->register(new OWBN_Entity_Staff_Tag());
		$dynamic_tags->register(new OWBN_Entity_Sessions_Tag());
		$dynamic_tags->register(new OWBN_Entity_Links_Tag());
	}
}

// Initialize on plugins_loaded
add_action('plugins_loaded', ['OWBN_Dynamic_Tags_Loader', 'init'], 20);
