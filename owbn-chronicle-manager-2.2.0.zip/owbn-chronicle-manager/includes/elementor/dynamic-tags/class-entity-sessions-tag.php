<?php
/**
 * Entity Sessions Dynamic Tag
 *
 * Renders session list for the current chronicle.
 * Shows session day/time, frequency, genres, and notes.
 *
 * @package OWBN-Chronicle-Manager
 * @version 2.2.0
 */

defined('ABSPATH') || exit;

class OWBN_Entity_Sessions_Tag extends \Elementor\Core\DynamicTags\Tag
{
	/**
	 * Get tag name.
	 *
	 * @return string
	 */
	public function get_name(): string
	{
		return 'owbn-entity-sessions';
	}

	/**
	 * Get tag title.
	 *
	 * @return string
	 */
	public function get_title(): string
	{
		return __('Entity Sessions', 'owbn-chronicle-manager');
	}

	/**
	 * Get tag group.
	 *
	 * @return string
	 */
	public function get_group(): string
	{
		return 'owbn-entity';
	}

	/**
	 * Get tag categories.
	 *
	 * @return array
	 */
	public function get_categories(): array
	{
		return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
	}

	/**
	 * Register tag controls.
	 *
	 * @return void
	 */
	protected function register_controls(): void
	{
		$this->add_control(
			'max_sessions',
			[
				'label'   => __('Max Sessions', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 0,
				'min'     => 0,
				'description' => __('0 = show all', 'owbn-chronicle-manager'),
			]
		);

		$this->add_control(
			'show_genres',
			[
				'label'   => __('Show Genres', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_notes',
			[
				'label'   => __('Show Notes', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
	}

	/**
	 * Render the tag output.
	 *
	 * @return void
	 */
	public function render(): void
	{
		$settings = $this->get_settings();
		$post_id  = get_the_ID();

		// Get sessions data
		$sessions = get_post_meta($post_id, 'session_times', true);

		if (!is_array($sessions) || empty($sessions)) {
			return;
		}

		// Limit sessions if requested
		$max_sessions = absint($settings['max_sessions'] ?? 0);
		if ($max_sessions > 0) {
			$sessions = array_slice($sessions, 0, $max_sessions);
		}

		$show_genres = ($settings['show_genres'] ?? 'yes') === 'yes';
		$show_notes  = ($settings['show_notes'] ?? 'yes') === 'yes';

		echo '<div class="owbn-entity-sessions">';

		foreach ($sessions as $session) {
			if (!is_array($session)) {
				continue;
			}

			echo '<div class="owbn-session-entry">';

			// Session type (header)
			$session_type = $session['session_type'] ?? 'Session';
			echo '<h4 class="session-type">' . esc_html($session_type) . '</h4>';

			// Frequency, Day, Times
			$parts = [];

			if (!empty($session['frequency'])) {
				$parts[] = esc_html($session['frequency']);
			}

			if (!empty($session['day'])) {
				$parts[] = esc_html($session['day']);
			}

			if (!empty($session['checkin_time'])) {
				$parts[] = __('Check-in:', 'owbn-chronicle-manager') . ' ' . esc_html($session['checkin_time']);
			}

			if (!empty($session['start_time'])) {
				$parts[] = __('Start:', 'owbn-chronicle-manager') . ' ' . esc_html($session['start_time']);
			}

			if (!empty($parts)) {
				echo '<div class="session-schedule">' . implode(' | ', $parts) . '</div>';
			}

			// Genres
			if ($show_genres && !empty($session['genres']) && is_array($session['genres'])) {
				echo '<div class="session-genres">';
				echo '<strong>' . __('Genres:', 'owbn-chronicle-manager') . '</strong> ';
				echo esc_html(implode(', ', $session['genres']));
				echo '</div>';
			}

			// Notes
			if ($show_notes && !empty($session['notes'])) {
				echo '<div class="session-notes">' . wp_kses_post(wpautop($session['notes'])) . '</div>';
			}

			echo '</div>'; // .owbn-session-entry
		}

		echo '</div>'; // .owbn-entity-sessions
	}
}
