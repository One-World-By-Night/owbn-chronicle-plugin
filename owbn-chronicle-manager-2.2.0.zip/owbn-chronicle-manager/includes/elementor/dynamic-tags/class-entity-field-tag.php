<?php
/**
 * Entity Field Dynamic Tag
 *
 * Generic tag that displays any entity field value with appropriate formatting.
 * Supports text, URL, email, date, boolean, select, and multi_select field types.
 *
 * @package OWBN-Chronicle-Manager
 * @version 2.2.0
 */

defined('ABSPATH') || exit;

class OWBN_Entity_Field_Tag extends \Elementor\Core\DynamicTags\Tag
{
	/**
	 * Get tag name.
	 *
	 * @return string
	 */
	public function get_name(): string
	{
		return 'owbn-entity-field';
	}

	/**
	 * Get tag title.
	 *
	 * @return string
	 */
	public function get_title(): string
	{
		return __('Entity Field', 'owbn-chronicle-manager');
	}

	/**
	 * Get tag group.
	 *
	 * @return string
	 */
	public function get_group(): string
	{
		return 'owbn-entity';
	}

	/**
	 * Get tag categories.
	 *
	 * @return array
	 */
	public function get_categories(): array
	{
		return [
			\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY,
			\Elementor\Modules\DynamicTags\Module::URL_CATEGORY,
		];
	}

	/**
	 * Register tag controls.
	 *
	 * @return void
	 */
	protected function register_controls(): void
	{
		$this->add_control(
			'field_key',
			[
				'label'       => __('Field', 'owbn-chronicle-manager'),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'options'     => $this->get_field_options(),
				'default'     => '',
				'label_block' => true,
			]
		);

		$this->add_control(
			'show_label',
			[
				'label'   => __('Show Label', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'no',
			]
		);

		$this->add_control(
			'custom_label',
			[
				'label'       => __('Custom Label', 'owbn-chronicle-manager'),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
				'condition'   => [
					'show_label' => 'yes',
				],
			]
		);

		$this->add_control(
			'date_format',
			[
				'label'   => __('Date Format', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'F j, Y'   => __('March 15, 2024', 'owbn-chronicle-manager'),
					'Y-m-d'    => __('2024-03-15', 'owbn-chronicle-manager'),
					'm/d/Y'    => __('03/15/2024', 'owbn-chronicle-manager'),
					'd/m/Y'    => __('15/03/2024', 'owbn-chronicle-manager'),
					'relative' => __('Relative (e.g., "2 days ago")', 'owbn-chronicle-manager'),
				],
				'default' => 'F j, Y',
			]
		);
	}

	/**
	 * Get available field options for the current post type.
	 *
	 * @return array
	 */
	protected function get_field_options(): array
	{
		$post_id = get_the_ID();

		if (!$post_id) {
			return ['' => __('Select a field', 'owbn-chronicle-manager')];
		}

		$post_type = get_post_type($post_id);
		$config    = owbn_get_entity_config($post_type);

		if (!$config) {
			return ['' => __('Not an entity post type', 'owbn-chronicle-manager')];
		}

		// Get field definitions from config
		$field_definitions = [];
		if (isset($config['field_definitions']) && is_callable($config['field_definitions'])) {
			$field_definitions = call_user_func($config['field_definitions']);
		}

		$options = ['' => __('Select a field', 'owbn-chronicle-manager')];

		foreach ($field_definitions as $field_id => $field) {
			$label = $field['label'] ?? ucfirst(str_replace('_', ' ', $field_id));
			$options[$field_id] = $label;
		}

		return $options;
	}

	/**
	 * Render the tag output.
	 *
	 * @return void
	 */
	public function render(): void
	{
		$settings  = $this->get_settings();
		$field_key = $settings['field_key'] ?? '';

		if (empty($field_key)) {
			return;
		}

		$post_id   = get_the_ID();
		$post_type = get_post_type($post_id);
		$config    = owbn_get_entity_config($post_type);

		if (!$config) {
			return;
		}

		// Get field value
		$value = get_post_meta($post_id, $field_key, true);

		if (empty($value)) {
			return;
		}

		// Get field definition for formatting
		$field_definitions = [];
		if (isset($config['field_definitions']) && is_callable($config['field_definitions'])) {
			$field_definitions = call_user_func($config['field_definitions']);
		}

		$field_def  = $field_definitions[$field_key] ?? [];
		$field_type = $field_def['type'] ?? 'text';

		// Format value based on field type
		$formatted_value = $this->format_field_value($value, $field_type, $field_def, $settings);

		// Show label if requested
		if (($settings['show_label'] ?? 'no') === 'yes') {
			$label = $settings['custom_label'] ?? $field_def['label'] ?? ucfirst(str_replace('_', ' ', $field_key));
			echo '<strong>' . esc_html($label) . ':</strong> ';
		}

		echo wp_kses_post($formatted_value);
	}

	/**
	 * Format field value based on field type.
	 *
	 * @param mixed  $value     Field value.
	 * @param string $type      Field type.
	 * @param array  $field_def Field definition.
	 * @param array  $settings  Tag settings.
	 * @return string Formatted value.
	 */
	protected function format_field_value($value, string $type, array $field_def, array $settings): string
	{
		switch ($type) {
			case 'url':
				return sprintf('<a href="%s" target="_blank" rel="noopener">%s</a>', esc_url($value), esc_html($value));

			case 'email':
				return sprintf('<a href="mailto:%s">%s</a>', esc_attr($value), esc_html($value));

			case 'date':
				$date_format = $settings['date_format'] ?? 'F j, Y';
				if ($date_format === 'relative') {
					return sprintf(__('%s ago', 'owbn-chronicle-manager'), human_time_diff(strtotime($value), current_time('timestamp')));
				}
				return date_i18n($date_format, strtotime($value));

			case 'boolean':
			case 'checkbox':
				return $value ? __('Yes', 'owbn-chronicle-manager') : __('No', 'owbn-chronicle-manager');

			case 'select':
				// If field has options, look up the label
				if (isset($field_def['options']) && is_array($field_def['options'])) {
					return $field_def['options'][$value] ?? $value;
				}
				return $value;

			case 'multi_select':
				if (is_array($value)) {
					// If field has options, look up labels
					if (isset($field_def['options']) && is_array($field_def['options'])) {
						$labels = array_map(function ($val) use ($field_def) {
							return $field_def['options'][$val] ?? $val;
						}, $value);
						return implode(', ', $labels);
					}
					return implode(', ', $value);
				}
				return $value;

			case 'textarea':
				return wpautop($value);

			case 'wysiwyg':
				return wpautop($value);

			default:
				return esc_html($value);
		}
	}
}
