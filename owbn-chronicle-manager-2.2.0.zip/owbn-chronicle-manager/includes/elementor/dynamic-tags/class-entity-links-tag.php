<?php
/**
 * Entity Links Dynamic Tag
 *
 * Renders document links, social media URLs, and email lists for the current entity.
 *
 * @package OWBN-Chronicle-Manager
 * @version 2.2.0
 */

defined('ABSPATH') || exit;

class OWBN_Entity_Links_Tag extends \Elementor\Core\DynamicTags\Tag
{
	/**
	 * Get tag name.
	 *
	 * @return string
	 */
	public function get_name(): string
	{
		return 'owbn-entity-links';
	}

	/**
	 * Get tag title.
	 *
	 * @return string
	 */
	public function get_title(): string
	{
		return __('Entity Links', 'owbn-chronicle-manager');
	}

	/**
	 * Get tag group.
	 *
	 * @return string
	 */
	public function get_group(): string
	{
		return 'owbn-entity';
	}

	/**
	 * Get tag categories.
	 *
	 * @return array
	 */
	public function get_categories(): array
	{
		return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
	}

	/**
	 * Register tag controls.
	 *
	 * @return void
	 */
	protected function register_controls(): void
	{
		$this->add_control(
			'link_types',
			[
				'label'       => __('Link Types to Show', 'owbn-chronicle-manager'),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => [
					'documents' => __('Documents', 'owbn-chronicle-manager'),
					'social'    => __('Social Media', 'owbn-chronicle-manager'),
					'email'     => __('Email Lists', 'owbn-chronicle-manager'),
				],
				'default'     => ['documents', 'social', 'email'],
				'label_block' => true,
			]
		);

		$this->add_control(
			'show_icons',
			[
				'label'   => __('Show Icons', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
	}

	/**
	 * Render the tag output.
	 *
	 * @return void
	 */
	public function render(): void
	{
		$settings   = $this->get_settings();
		$link_types = $settings['link_types'] ?? ['documents', 'social', 'email'];
		$show_icons = ($settings['show_icons'] ?? 'yes') === 'yes';

		$post_id = get_the_ID();

		echo '<div class="owbn-entity-links">';

		// Document Links
		if (in_array('documents', $link_types, true)) {
			$this->render_document_links($post_id, $show_icons);
		}

		// Social Media Links
		if (in_array('social', $link_types, true)) {
			$this->render_social_links($post_id, $show_icons);
		}

		// Email Lists
		if (in_array('email', $link_types, true)) {
			$this->render_email_lists($post_id, $show_icons);
		}

		echo '</div>';
	}

	/**
	 * Render document links.
	 *
	 * @param int  $post_id    Post ID.
	 * @param bool $show_icons Whether to show icons.
	 * @return void
	 */
	protected function render_document_links(int $post_id, bool $show_icons): void
	{
		$document_links = get_post_meta($post_id, 'document_links', true);

		if (!is_array($document_links) || empty($document_links)) {
			return;
		}

		echo '<div class="owbn-document-links">';
		echo '<h3>' . __('Documents', 'owbn-chronicle-manager') . '</h3>';
		echo '<ul>';

		foreach ($document_links as $doc) {
			$title = $doc['title'] ?? 'Document';
			$url   = '';

			// Prioritize upload over external link
			if (!empty($doc['file_id'])) {
				$url = wp_get_attachment_url($doc['file_id']);
			} elseif (!empty($doc['link'])) {
				$url = $doc['link'];
			}

			if (empty($url)) {
				continue;
			}

			echo '<li>';
			if ($show_icons) {
				echo '<i class="fas fa-file-alt"></i> ';
			}
			echo '<a href="' . esc_url($url) . '" target="_blank" rel="noopener">' . esc_html($title) . '</a>';
			echo '</li>';
		}

		echo '</ul>';
		echo '</div>';
	}

	/**
	 * Render social media links.
	 *
	 * @param int  $post_id    Post ID.
	 * @param bool $show_icons Whether to show icons.
	 * @return void
	 */
	protected function render_social_links(int $post_id, bool $show_icons): void
	{
		$social_links = get_post_meta($post_id, 'social_urls', true);

		if (!is_array($social_links) || empty($social_links)) {
			return;
		}

		$icon_map = [
			'facebook'  => 'fa-brands fa-facebook',
			'instagram' => 'fa-brands fa-instagram',
			'twitter'   => 'fa-brands fa-twitter',
			'discord'   => 'fa-brands fa-discord',
			'slack'     => 'fa-brands fa-slack',
			'linkedin'  => 'fa-brands fa-linkedin',
			'youtube'   => 'fa-brands fa-youtube',
			'twitch'    => 'fa-brands fa-twitch',
			'tiktok'    => 'fa-brands fa-tiktok',
			'pinterest' => 'fa-brands fa-pinterest',
			'reddit'    => 'fa-brands fa-reddit',
			'custom'    => 'fas fa-link',
		];

		echo '<div class="owbn-social-links">';
		echo '<h3>' . __('Social Media', 'owbn-chronicle-manager') . '</h3>';
		echo '<ul>';

		foreach ($social_links as $link) {
			$platform = $link['platform'] ?? '';
			$url      = $link['url'] ?? '';

			if (empty($url)) {
				continue;
			}

			$label = ucfirst($platform);
			$icon  = $icon_map[$platform] ?? 'fas fa-link';

			echo '<li>';
			if ($show_icons) {
				echo '<i class="' . esc_attr($icon) . '"></i> ';
			}
			echo '<a href="' . esc_url($url) . '" target="_blank" rel="noopener">' . esc_html($label) . '</a>';
			echo '</li>';
		}

		echo '</ul>';
		echo '</div>';
	}

	/**
	 * Render email lists.
	 *
	 * @param int  $post_id    Post ID.
	 * @param bool $show_icons Whether to show icons.
	 * @return void
	 */
	protected function render_email_lists(int $post_id, bool $show_icons): void
	{
		$email_lists = get_post_meta($post_id, 'email_lists', true);

		if (!is_array($email_lists) || empty($email_lists)) {
			return;
		}

		echo '<div class="owbn-email-lists">';
		echo '<h3>' . __('Email Lists', 'owbn-chronicle-manager') . '</h3>';
		echo '<ul>';

		foreach ($email_lists as $email_entry) {
			$label = $email_entry['label'] ?? 'Email List';
			$email = $email_entry['email'] ?? '';

			if (empty($email)) {
				continue;
			}

			echo '<li>';
			if ($show_icons) {
				echo '<i class="fas fa-envelope"></i> ';
			}
			echo '<a href="mailto:' . esc_attr($email) . '">' . esc_html($label) . '</a>';
			echo '</li>';
		}

		echo '</ul>';
		echo '</div>';
	}
}
