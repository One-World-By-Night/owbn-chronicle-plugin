<?php
/**
 * Elementor Theme Builder Integration
 *
 * Registers OWBN entity post types (chronicles, coordinators) with Elementor Pro's
 * Theme Builder so users can design single-entity templates visually.
 *
 * @package OWBN-Chronicle-Manager
 * @version 2.2.0
 */

defined('ABSPATH') || exit;

/**
 * Add OWBN post types to Elementor Theme Builder conditions.
 *
 * This allows users to create "Single" templates that target specific
 * OWBN entity types (e.g., "Single > Chronicle" or "Single > Coordinator").
 *
 * @param \ElementorPro\Modules\ThemeBuilder\Classes\Conditions_Manager $conditions_manager
 * @return void
 */
function owbn_register_theme_builder_conditions($conditions_manager): void
{
	// Get registered entity types
	$entity_types = owbn_get_entity_types();

	if (empty($entity_types)) {
		return;
	}

	foreach ($entity_types as $post_type => $config) {
		// Skip if entity type is disabled
		if (!owbn_is_entity_enabled($post_type)) {
			continue;
		}

		// Register condition for this post type
		$conditions_manager->get_condition('singular')->register_sub_condition(
			new \ElementorPro\Modules\ThemeBuilder\Conditions\Post(
				[
					'name'      => $post_type,
					'label'     => $config['singular'] ?? ucfirst($post_type),
					'post_type' => $post_type,
				]
			)
		);
	}
}

/**
 * Enable Elementor editor for OWBN post types.
 *
 * Allows users to edit entity posts (chronicles, coordinators) with Elementor
 * if they choose to create content that way.
 *
 * @param bool   $is_supported Whether Elementor is supported for this post type.
 * @param int    $post_id      The post ID.
 * @param string $post_type    The post type.
 * @return bool
 */
function owbn_enable_elementor_editor($is_supported, $post_id, $post_type): bool
{
	if (owbn_is_entity_post_type($post_type)) {
		return true;
	}

	return $is_supported;
}

/**
 * Initialize Elementor Theme Builder integration.
 *
 * Handles both load orders: our plugin loading before/after Elementor Pro.
 *
 * @return void
 */
function owbn_init_elementor_theme_builder(): void
{
	// Check if Elementor Pro is available
	if (!did_action('elementor_pro/init')) {
		// Wait for Elementor Pro to load
		add_action('elementor_pro/init', 'owbn_init_elementor_theme_builder');
		return;
	}

	// Register hooks
	add_action('elementor/theme/register_conditions', 'owbn_register_theme_builder_conditions');
	add_filter('elementor/utils/is_post_support', 'owbn_enable_elementor_editor', 10, 3);
}

// Initialize on plugins_loaded to ensure entity registry is ready
add_action('plugins_loaded', 'owbn_init_elementor_theme_builder', 20);
