<?php
/**
 * Entity Links Widget
 *
 * Displays document links, social media URLs, and email lists with styling controls.
 *
 * @package OWBN-Chronicle-Manager
 * @version 2.2.0
 */

defined('ABSPATH') || exit;

class OWBN_Links_Widget extends \Elementor\Widget_Base
{
	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name(): string
	{
		return 'owbn_links';
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title(): string
	{
		return __('Entity Links', 'owbn-chronicle-manager');
	}

	/**
	 * Get widget icon.
	 *
	 * @return string
	 */
	public function get_icon(): string
	{
		return 'eicon-link';
	}

	/**
	 * Get widget categories.
	 *
	 * @return array
	 */
	public function get_categories(): array
	{
		return ['owbn-entities'];
	}

	/**
	 * Register widget controls.
	 *
	 * @return void
	 */
	protected function register_controls(): void
	{
		// Content Controls
		$this->start_controls_section(
			'content_section',
			[
				'label' => __('Content', 'owbn-chronicle-manager'),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'link_types',
			[
				'label'       => __('Link Types to Show', 'owbn-chronicle-manager'),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => [
					'documents' => __('Documents', 'owbn-chronicle-manager'),
					'social'    => __('Social Media', 'owbn-chronicle-manager'),
					'email'     => __('Email Lists', 'owbn-chronicle-manager'),
				],
				'default'     => ['documents', 'social', 'email'],
				'label_block' => true,
			]
		);

		$this->add_control(
			'show_icons',
			[
				'label'   => __('Show Icons', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_section_titles',
			[
				'label'   => __('Show Section Titles', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		// Style: Section Title
		$this->start_controls_section(
			'section_title_style',
			[
				'label'     => __('Section Title', 'owbn-chronicle-manager'),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_section_titles' => 'yes',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'section_title_typography',
				'selector' => '{{WRAPPER}} .owbn-links-section-title',
			]
		);

		$this->add_control(
			'section_title_color',
			[
				'label'     => __('Color', 'owbn-chronicle-manager'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owbn-links-section-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// Style: Links
		$this->start_controls_section(
			'links_style',
			[
				'label' => __('Links', 'owbn-chronicle-manager'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'link_typography',
				'selector' => '{{WRAPPER}} .owbn-link-item a',
			]
		);

		$this->start_controls_tabs('link_colors_tabs');

		$this->start_controls_tab(
			'link_normal_tab',
			[
				'label' => __('Normal', 'owbn-chronicle-manager'),
			]
		);

		$this->add_control(
			'link_color',
			[
				'label'     => __('Color', 'owbn-chronicle-manager'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owbn-link-item a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'link_hover_tab',
			[
				'label' => __('Hover', 'owbn-chronicle-manager'),
			]
		);

		$this->add_control(
			'link_hover_color',
			[
				'label'     => __('Color', 'owbn-chronicle-manager'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owbn-link-item a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'link_spacing',
			[
				'label'      => __('Link Spacing', 'owbn-chronicle-manager'),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', 'em'],
				'range'      => [
					'px' => ['min' => 0, 'max' => 30],
					'em' => ['min' => 0, 'max' => 3],
				],
				'selectors'  => [
					'{{WRAPPER}} .owbn-link-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Style: Icon
		$this->start_controls_section(
			'icon_style',
			[
				'label'     => __('Icon', 'owbn-chronicle-manager'),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_icons' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'      => __('Size', 'owbn-chronicle-manager'),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', 'em'],
				'range'      => [
					'px' => ['min' => 10, 'max' => 50],
					'em' => ['min' => 0.5, 'max' => 5],
				],
				'selectors'  => [
					'{{WRAPPER}} .owbn-link-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => __('Color', 'owbn-chronicle-manager'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owbn-link-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_spacing',
			[
				'label'      => __('Spacing', 'owbn-chronicle-manager'),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', 'em'],
				'range'      => [
					'px' => ['min' => 0, 'max' => 20],
					'em' => ['min' => 0, 'max' => 2],
				],
				'selectors'  => [
					'{{WRAPPER}} .owbn-link-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output.
	 *
	 * @return void
	 */
	protected function render(): void
	{
		$settings   = $this->get_settings_for_display();
		$link_types = $settings['link_types'] ?? ['documents', 'social', 'email'];
		$show_icons = ($settings['show_icons'] ?? 'yes') === 'yes';
		$show_titles = ($settings['show_section_titles'] ?? 'yes') === 'yes';

		$post_id = get_the_ID();

		echo '<div class="owbn-links-container">';

		// Document Links
		if (in_array('documents', $link_types, true)) {
			$this->render_document_links($post_id, $show_icons, $show_titles);
		}

		// Social Media Links
		if (in_array('social', $link_types, true)) {
			$this->render_social_links($post_id, $show_icons, $show_titles);
		}

		// Email Lists
		if (in_array('email', $link_types, true)) {
			$this->render_email_lists($post_id, $show_icons, $show_titles);
		}

		echo '</div>';
	}

	/**
	 * Render document links.
	 *
	 * @param int  $post_id     Post ID.
	 * @param bool $show_icons  Whether to show icons.
	 * @param bool $show_titles Whether to show section titles.
	 * @return void
	 */
	protected function render_document_links(int $post_id, bool $show_icons, bool $show_titles): void
	{
		$document_links = get_post_meta($post_id, 'document_links', true);

		if (!is_array($document_links) || empty($document_links)) {
			return;
		}

		echo '<div class="owbn-links-section">';

		if ($show_titles) {
			echo '<h3 class="owbn-links-section-title">' . __('Documents', 'owbn-chronicle-manager') . '</h3>';
		}

		echo '<ul class="owbn-links-list">';

		foreach ($document_links as $doc) {
			$title = $doc['title'] ?? 'Document';
			$url   = '';

			// Prioritize upload over external link
			if (!empty($doc['file_id'])) {
				$url = wp_get_attachment_url($doc['file_id']);
			} elseif (!empty($doc['link'])) {
				$url = $doc['link'];
			}

			if (empty($url)) {
				continue;
			}

			echo '<li class="owbn-link-item">';
			if ($show_icons) {
				echo '<i class="owbn-link-icon fas fa-file-alt"></i>';
			}
			echo '<a href="' . esc_url($url) . '" target="_blank" rel="noopener">' . esc_html($title) . '</a>';
			echo '</li>';
		}

		echo '</ul>';
		echo '</div>';
	}

	/**
	 * Render social media links.
	 *
	 * @param int  $post_id     Post ID.
	 * @param bool $show_icons  Whether to show icons.
	 * @param bool $show_titles Whether to show section titles.
	 * @return void
	 */
	protected function render_social_links(int $post_id, bool $show_icons, bool $show_titles): void
	{
		$social_links = get_post_meta($post_id, 'social_urls', true);

		if (!is_array($social_links) || empty($social_links)) {
			return;
		}

		$icon_map = [
			'facebook'  => 'fa-brands fa-facebook',
			'instagram' => 'fa-brands fa-instagram',
			'twitter'   => 'fa-brands fa-twitter',
			'discord'   => 'fa-brands fa-discord',
			'slack'     => 'fa-brands fa-slack',
			'linkedin'  => 'fa-brands fa-linkedin',
			'youtube'   => 'fa-brands fa-youtube',
			'twitch'    => 'fa-brands fa-twitch',
			'tiktok'    => 'fa-brands fa-tiktok',
			'pinterest' => 'fa-brands fa-pinterest',
			'reddit'    => 'fa-brands fa-reddit',
			'custom'    => 'fas fa-link',
		];

		echo '<div class="owbn-links-section">';

		if ($show_titles) {
			echo '<h3 class="owbn-links-section-title">' . __('Social Media', 'owbn-chronicle-manager') . '</h3>';
		}

		echo '<ul class="owbn-links-list">';

		foreach ($social_links as $link) {
			$platform = $link['platform'] ?? '';
			$url      = $link['url'] ?? '';

			if (empty($url)) {
				continue;
			}

			$label = ucfirst($platform);
			$icon  = $icon_map[$platform] ?? 'fas fa-link';

			echo '<li class="owbn-link-item">';
			if ($show_icons) {
				echo '<i class="owbn-link-icon ' . esc_attr($icon) . '"></i>';
			}
			echo '<a href="' . esc_url($url) . '" target="_blank" rel="noopener">' . esc_html($label) . '</a>';
			echo '</li>';
		}

		echo '</ul>';
		echo '</div>';
	}

	/**
	 * Render email lists.
	 *
	 * @param int  $post_id     Post ID.
	 * @param bool $show_icons  Whether to show icons.
	 * @param bool $show_titles Whether to show section titles.
	 * @return void
	 */
	protected function render_email_lists(int $post_id, bool $show_icons, bool $show_titles): void
	{
		$email_lists = get_post_meta($post_id, 'email_lists', true);

		if (!is_array($email_lists) || empty($email_lists)) {
			return;
		}

		echo '<div class="owbn-links-section">';

		if ($show_titles) {
			echo '<h3 class="owbn-links-section-title">' . __('Email Lists', 'owbn-chronicle-manager') . '</h3>';
		}

		echo '<ul class="owbn-links-list">';

		foreach ($email_lists as $email_entry) {
			$label = $email_entry['label'] ?? 'Email List';
			$email = $email_entry['email'] ?? '';

			if (empty($email)) {
				continue;
			}

			echo '<li class="owbn-link-item">';
			if ($show_icons) {
				echo '<i class="owbn-link-icon fas fa-envelope"></i>';
			}
			echo '<a href="mailto:' . esc_attr($email) . '">' . esc_html($label) . '</a>';
			echo '</li>';
		}

		echo '</ul>';
		echo '</div>';
	}
}
