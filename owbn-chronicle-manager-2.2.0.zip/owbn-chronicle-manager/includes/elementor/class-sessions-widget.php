<?php
/**
 * Sessions Widget
 *
 * Displays game session information (day/time, frequency, genres, etc.) with styling controls.
 *
 * @package OWBN-Chronicle-Manager
 * @version 2.2.0
 */

defined('ABSPATH') || exit;

class OWBN_Sessions_Widget extends \Elementor\Widget_Base
{
	/**
	 * Get widget name.
	 *
	 * @return string
	 */
	public function get_name(): string
	{
		return 'owbn_sessions';
	}

	/**
	 * Get widget title.
	 *
	 * @return string
	 */
	public function get_title(): string
	{
		return __('Entity Sessions', 'owbn-chronicle-manager');
	}

	/**
	 * Get widget icon.
	 *
	 * @return string
	 */
	public function get_icon(): string
	{
		return 'eicon-calendar';
	}

	/**
	 * Get widget categories.
	 *
	 * @return array
	 */
	public function get_categories(): array
	{
		return ['owbn-entities'];
	}

	/**
	 * Register widget controls.
	 *
	 * @return void
	 */
	protected function register_controls(): void
	{
		// Content Controls
		$this->start_controls_section(
			'content_section',
			[
				'label' => __('Content', 'owbn-chronicle-manager'),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'max_sessions',
			[
				'label'       => __('Max Sessions', 'owbn-chronicle-manager'),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 0,
				'min'         => 0,
				'description' => __('0 = show all', 'owbn-chronicle-manager'),
			]
		);

		$this->add_control(
			'show_genres',
			[
				'label'   => __('Show Genres', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_notes',
			[
				'label'   => __('Show Notes', 'owbn-chronicle-manager'),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		// Style: Session Type
		$this->start_controls_section(
			'session_type_style',
			[
				'label' => __('Session Type', 'owbn-chronicle-manager'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'session_type_typography',
				'selector' => '{{WRAPPER}} .owbn-session-type',
			]
		);

		$this->add_control(
			'session_type_color',
			[
				'label'     => __('Color', 'owbn-chronicle-manager'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owbn-session-type' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// Style: Schedule Text
		$this->start_controls_section(
			'schedule_style',
			[
				'label' => __('Schedule Text', 'owbn-chronicle-manager'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'schedule_typography',
				'selector' => '{{WRAPPER}} .owbn-session-schedule',
			]
		);

		$this->add_control(
			'schedule_color',
			[
				'label'     => __('Color', 'owbn-chronicle-manager'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owbn-session-schedule' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// Style: Container
		$this->start_controls_section(
			'container_style',
			[
				'label' => __('Container', 'owbn-chronicle-manager'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'session_spacing',
			[
				'label'      => __('Session Spacing', 'owbn-chronicle-manager'),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px', 'em'],
				'range'      => [
					'px' => ['min' => 0, 'max' => 50],
					'em' => ['min' => 0, 'max' => 5],
				],
				'selectors'  => [
					'{{WRAPPER}} .owbn-session-entry' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'     => 'session_background',
				'selector' => '{{WRAPPER}} .owbn-session-entry',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'session_border',
				'selector' => '{{WRAPPER}} .owbn-session-entry',
			]
		);

		$this->add_responsive_control(
			'session_padding',
			[
				'label'      => __('Padding', 'owbn-chronicle-manager'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .owbn-session-entry' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output.
	 *
	 * @return void
	 */
	protected function render(): void
	{
		$settings = $this->get_settings_for_display();
		$post_id  = get_the_ID();

		// Get sessions data
		$sessions = get_post_meta($post_id, 'session_times', true);

		if (!is_array($sessions) || empty($sessions)) {
			echo '<p>' . __('No sessions configured.', 'owbn-chronicle-manager') . '</p>';
			return;
		}

		// Limit sessions if requested
		$max_sessions = absint($settings['max_sessions'] ?? 0);
		if ($max_sessions > 0) {
			$sessions = array_slice($sessions, 0, $max_sessions);
		}

		$show_genres = ($settings['show_genres'] ?? 'yes') === 'yes';
		$show_notes  = ($settings['show_notes'] ?? 'yes') === 'yes';

		echo '<div class="owbn-sessions-container">';

		foreach ($sessions as $session) {
			if (!is_array($session)) {
				continue;
			}

			echo '<div class="owbn-session-entry">';

			// Session type (header)
			$session_type = $session['session_type'] ?? 'Session';
			echo '<h4 class="owbn-session-type">' . esc_html($session_type) . '</h4>';

			// Frequency, Day, Times
			$parts = [];

			if (!empty($session['frequency'])) {
				$parts[] = esc_html($session['frequency']);
			}

			if (!empty($session['day'])) {
				$parts[] = esc_html($session['day']);
			}

			if (!empty($session['checkin_time'])) {
				$parts[] = __('Check-in:', 'owbn-chronicle-manager') . ' ' . esc_html($session['checkin_time']);
			}

			if (!empty($session['start_time'])) {
				$parts[] = __('Start:', 'owbn-chronicle-manager') . ' ' . esc_html($session['start_time']);
			}

			if (!empty($parts)) {
				echo '<div class="owbn-session-schedule">' . implode(' | ', $parts) . '</div>';
			}

			// Genres
			if ($show_genres && !empty($session['genres']) && is_array($session['genres'])) {
				echo '<div class="owbn-session-genres">';
				echo '<strong>' . __('Genres:', 'owbn-chronicle-manager') . '</strong> ';
				echo esc_html(implode(', ', $session['genres']));
				echo '</div>';
			}

			// Notes
			if ($show_notes && !empty($session['notes'])) {
				echo '<div class="owbn-session-notes">' . wp_kses_post(wpautop($session['notes'])) . '</div>';
			}

			echo '</div>'; // .owbn-session-entry
		}

		echo '</div>'; // .owbn-sessions-container
	}
}
