<?php

/** File: includes/languages/_template.php
 * Text Domain: accessschema-client
 * version 1.2.0
 * @author greghacke
 * Function: Template for language files in the AccessSchema client plugin
 */

defined( 'ABSPATH' ) || exit;