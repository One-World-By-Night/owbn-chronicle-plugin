<?php

/** File: prefix.php
 * Text Domain: accessschema-client
 * version 1.2.0
 * @author greghacke
 * Function: 
 */

defined('ABSPATH') || exit;

// Unique constant prefix for this embedded instance of accessSchema-client
define('ASC_PREFIX', 'CCS');                // Change 'YPP' to your plugin's unique prefix
define('ASC_LABEL', 'C&C Schema');   // Change 'Your Plugin Label' to your plugin's label